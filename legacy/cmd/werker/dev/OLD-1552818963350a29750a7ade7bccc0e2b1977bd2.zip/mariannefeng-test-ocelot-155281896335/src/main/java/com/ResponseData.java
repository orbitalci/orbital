package com;

/**
 * Marker interface for that an object that will be passed back to the user
 *
 * Created by mariannefeng on 6/17/16.
 */

public interface ResponseData {}
